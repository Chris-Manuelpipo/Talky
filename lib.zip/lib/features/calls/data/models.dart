// lib/features/calls/data/models.dart
//
// Models pour les appels

// ──────────────────────────────────────────────────────────────────
// CallStatus - État d'un appel
// ──────────────────────────────────────────────────────────────────
enum CallStatus {
  idle,      // Pas d'appel
  ringing,   // Appel entrant en cours de sonnerie
  calling,   // Appel en cours d'établissement
  connected, // Appel établi et actif
  ended,     // Appel terminé
  failed,    // Appel échoué
}

// ──────────────────────────────────────────────────────────────────
// GroupParticipant - Participant d'un appel de groupe
// ──────────────────────────────────────────────────────────────────
class GroupParticipant {
  final int userId;
  final String name;
  final String? photo;
  final bool isConnected;
  final bool isMuted;
  final bool isCameraOff;

  GroupParticipant({
    required this.userId,
    required this.name,
    this.photo,
    this.isConnected = false,
    this.isMuted = false,
    this.isCameraOff = false,
  });

  GroupParticipant copyWith({
    int? userId,
    String? name,
    String? photo,
    bool? isConnected,
    bool? isMuted,
    bool? isCameraOff,
  }) {
    return GroupParticipant(
      userId: userId ?? this.userId,
      name: name ?? this.name,
      photo: photo ?? this.photo,
      isConnected: isConnected ?? this.isConnected,
      isMuted: isMuted ?? this.isMuted,
      isCameraOff: isCameraOff ?? this.isCameraOff,
    );
  }
}
